#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct{
	u_short len;
	char flag;
}A;

int main(){
/*	char number[10]="ad1db234";
	printf("%d\n", atoi(number));

	int int_num=0x3034;
	printf("%d\n", int_num);
	u_short short_num = 52;
	char* num;
	num = (char*)(&short_num);
	num[0] = '0', num[1]='4';
	printf("%02x %02x\n", num[0], num[1]);
	printf("%d\n", short_num);
	return 0;
	*/
	printf("u_short length:%d", sizeof(u_short));
	char packet[3] = {0, 34, 31};
	A* a = (A*)packet;
	printf("A->len:%d\nA->flag:%c\n", a->len, a->flag);
	return 0;

}
